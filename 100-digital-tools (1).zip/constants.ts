
import { Tool } from './types';

export enum Category {
  DESIGN = 'Design',
  DEVELOPMENT = 'Development',
  PRODUCTIVITY = 'Productivity',
  WRITING = 'Writing',
  MARKETING = 'Marketing',
  UTILITIES = 'Utilities',
  FINANCE = 'Finance',
  AI = 'AI',
}

export const CATEGORIES: Category[] = [
  Category.DESIGN,
  Category.DEVELOPMENT,
  Category.PRODUCTIVITY,
  Category.WRITING,
  Category.MARKETING,
  Category.UTILITIES,
  Category.FINANCE,
  Category.AI,
];

export const CATEGORY_STYLES: { [key in Category]: { color: string; icon: string } } = {
  [Category.DESIGN]: { color: 'bg-purple-500', icon: '🎨' },
  [Category.DEVELOPMENT]: { color: 'bg-blue-500', icon: '💻' },
  [Category.PRODUCTIVITY]: { color: 'bg-green-500', icon: '🚀' },
  [Category.WRITING]: { color: 'bg-yellow-500', icon: '✍️' },
  [Category.MARKETING]: { color: 'bg-red-500', icon: '📈' },
  [Category.UTILITIES]: { color: 'bg-indigo-500', icon: '🔧' },
  [Category.FINANCE]: { color: 'bg-pink-500', icon: '💰' },
  [Category.AI]: { color: 'bg-teal-500', icon: '🤖' },
};


export const TOOLS: Tool[] = [
  // Design
  { name: 'Figma', description: 'Collaborative interface design tool.', link: 'https://figma.com', category: Category.DESIGN, icon: '🎨' },
  { name: 'Canva', description: 'Graphic design for everyone.', link: 'https://canva.com', category: Category.DESIGN, icon: '🎨' },
  { name: 'Adobe XD', description: 'Vector-based UX design tool.', link: 'https://www.adobe.com/products/xd.html', category: Category.DESIGN, icon: '🎨' },
  { name: 'Sketch', description: 'Digital design toolkit for macOS.', link: 'https://sketch.com', category: Category.DESIGN, icon: '🎨' },
  { name: 'InVision', description: 'Digital product design platform.', link: 'https://invisionapp.com', category: Category.DESIGN, icon: '🎨' },
  { name: 'Coolors', description: 'Fast color schemes generator.', link: 'https://coolors.co', category: Category.DESIGN, icon: '🎨' },
  { name: 'Unsplash', description: 'Free high-resolution photos.', link: 'https://unsplash.com', category: Category.DESIGN, icon: '🎨' },
  { name: 'Pexels', description: 'Free stock photos & videos.', link: 'https://pexels.com', category: Category.DESIGN, icon: '🎨' },
  { name: 'Fontjoy', description: 'Generate font pairings in one click.', link: 'https://fontjoy.com', category: Category.DESIGN, icon: '🎨' },
  { name: 'LottieFiles', description: 'Library of free animations.', link: 'https://lottiefiles.com', category: Category.DESIGN, icon: '🎨' },
  { name: 'Remove.bg', description: 'Remove image backgrounds 100% automatically.', link: 'https://remove.bg', category: Category.DESIGN, icon: '🎨' },
  { name: 'Spline', description: 'Create 3D scenes for the web.', link: 'https://spline.design', category: Category.DESIGN, icon: '🎨' },

  // Development
  { name: 'VS Code', description: 'Free source-code editor.', link: 'https://code.visualstudio.com', category: Category.DEVELOPMENT, icon: '💻' },
  { name: 'GitHub', description: 'Code hosting and collaboration.', link: 'https://github.com', category: Category.DEVELOPMENT, icon: '💻' },
  { name: 'GitLab', description: 'The One DevOps Platform.', link: 'https://gitlab.com', category: Category.DEVELOPMENT, icon: '💻' },
  { name: 'Postman', description: 'API platform for building and using APIs.', link: 'https://postman.com', category: Category.DEVELOPMENT, icon: '💻' },
  { name: 'Docker', description: 'Securely build, share and run any application.', link: 'https://docker.com', category: Category.DEVELOPMENT, icon: '💻' },
  { name: 'Netlify', description: 'Platform for modern web projects.', link: 'https://netlify.com', category: Category.DEVELOPMENT, icon: '💻' },
  { name: 'Vercel', description: 'Develop, preview, and ship.', link: 'https://vercel.com', category: Category.DEVELOPMENT, icon: '💻' },
  { name: 'Stack Overflow', description: 'Q&A for professional and enthusiast programmers.', link: 'https://stackoverflow.com', category: Category.DEVELOPMENT, icon: '💻' },
  { name: 'CodePen', description: 'Online code editor and open-source learning environment.', link: 'https://codepen.io', category: Category.DEVELOPMENT, icon: '💻' },
  { name: 'Firebase', description: 'Google\'s mobile application development platform.', link: 'https://firebase.google.com', category: Category.DEVELOPMENT, icon: '💻' },
  { name: 'Jira', description: 'Issue & project tracking software.', link: 'https://www.atlassian.com/software/jira', category: Category.DEVELOPMENT, icon: '💻' },
  { name: 'Toptal', description: 'Hire freelance talent.', link: 'https://www.toptal.com/', category: Category.DEVELOPMENT, icon: '💻' },

  // Productivity
  { name: 'Notion', description: 'The all-in-one workspace.', link: 'https://notion.so', category: Category.PRODUCTIVITY, icon: '🚀' },
  { name: 'Trello', description: 'Visual collaboration tool.', link: 'https://trello.com', category: Category.PRODUCTIVITY, icon: '🚀' },
  { name: 'Asana', description: 'Work management platform.', link: 'https://asana.com', category: Category.PRODUCTIVITY, icon: '🚀' },
  { name: 'Slack', description: 'Team communication platform.', link: 'https://slack.com', category: Category.PRODUCTIVITY, icon: '🚀' },
  { name: 'Todoist', description: 'The to-do list to organize work & life.', link: 'https://todoist.com', category: Category.PRODUCTIVITY, icon: '🚀' },
  { name: 'Evernote', description: 'Note-taking app.', link: 'https://evernote.com', category: Category.PRODUCTIVITY, icon: '🚀' },
  { name: 'Miro', description: 'Online collaborative whiteboard.', link: 'https://miro.com', category: Category.PRODUCTIVITY, icon: '🚀' },
  { name: 'ClickUp', description: 'One app to replace them all.', link: 'https://clickup.com', category: Category.PRODUCTIVITY, icon: '🚀' },
  { name: 'Zapier', description: 'Automate your work.', link: 'https://zapier.com', category: Category.PRODUCTIVITY, icon: '🚀' },
  { name: 'Calendly', description: 'Automated scheduling software.', link: 'https://calendly.com', category: Category.PRODUCTIVITY, icon: '🚀' },
  { name: 'Airtable', description: 'Low-code platform for building collaborative apps.', link: 'https://airtable.com', category: Category.PRODUCTIVITY, icon: '🚀' },
  { name: 'Loom', description: 'Video messaging for work.', link: 'https://loom.com', category: Category.PRODUCTIVITY, icon: '🚀' },
  { name: 'LastPass', description: 'Password manager.', link: 'https://lastpass.com', category: Category.PRODUCTIVITY, icon: '🚀' },
  
  // Writing
  { name: 'Grammarly', description: 'AI-powered writing assistant.', link: 'https://grammarly.com', category: Category.WRITING, icon: '✍️' },
  { name: 'Hemingway App', description: 'Makes your writing bold and clear.', link: 'https://hemingwayapp.com', category: Category.WRITING, icon: '✍️' },
  { name: 'Google Docs', description: 'Online word processor.', link: 'https://docs.google.com', category: Category.WRITING, icon: '✍️' },
  { name: 'Medium', description: 'Online publishing platform.', link: 'https://medium.com', category: Category.WRITING, icon: '✍️' },
  { name: 'Scrivener', description: 'The go-to app for writers.', link: 'https://www.literatureandlatte.com/scrivener/overview', category: Category.WRITING, icon: '✍️' },
  { name: 'Thesaurus.com', description: 'Find synonyms and antonyms.', link: 'https://thesaurus.com', category: Category.WRITING, icon: '✍️' },
  { name: 'QuillBot', description: 'Paraphrasing and summarizing tool.', link: 'https://quillbot.com', category: Category.WRITING, icon: '✍️' },
  { name: 'Cliche Finder', description: 'Find and remove cliches from your text.', link: 'http://cliche.theinfo.org/', category: Category.WRITING, icon: '✍️' },
  { name: 'Copy.ai', description: 'AI copywriter for marketing.', link: 'https://www.copy.ai/', category: Category.WRITING, icon: '✍️' },
  { name: 'Jasper', description: 'AI Content Platform for businesses.', link: 'https://www.jasper.ai/', category: Category.WRITING, icon: '✍️' },
  { name: 'ProWritingAid', description: 'Grammar checker, style editor, and writing mentor.', link: 'https://prowritingaid.com/', category: Category.WRITING, icon: '✍️' },

  // Marketing
  { name: 'SEMrush', description: 'Online visibility management platform.', link: 'https://semrush.com', category: Category.MARKETING, icon: '📈' },
  { name: 'Ahrefs', description: 'SEO Tools & Resources to Grow Your Search Traffic.', link: 'https://ahrefs.com', category: Category.MARKETING, icon: '📈' },
  { name: 'Google Analytics', description: 'Web analytics service.', link: 'https://analytics.google.com', category: Category.MARKETING, icon: '📈' },
  { name: 'Mailchimp', description: 'Email marketing platform.', link: 'https://mailchimp.com', category: Category.MARKETING, icon: '📈' },
  { name: 'HubSpot', description: 'CRM, marketing, sales, and service software.', link: 'https://hubspot.com', category: Category.MARKETING, icon: '📈' },
  { name: 'Buffer', description: 'Social media management platform.', link: 'https://buffer.com', category: Category.MARKETING, icon: '📈' },
  { name: 'Hotjar', description: 'Website heatmaps & behavior analytics tools.', link: 'https://hotjar.com', category: Category.MARKETING, icon: '📈' },
  { name: 'AnswerThePublic', description: 'Search listening tool for market research.', link: 'https://answerthepublic.com', category: Category.MARKETING, icon: '📈' },
  { name: 'SimilarWeb', description: 'Digital market intelligence platform.', link: 'https://www.similarweb.com/', category: Category.MARKETING, icon: '📈' },
  { name: 'BuzzSumo', description: 'Find content that performs best.', link: 'https://buzzsumo.com', category: Category.MARKETING, icon: '📈' },
  { name: 'Canva', description: 'Create social media graphics.', link: 'https://canva.com', category: Category.MARKETING, icon: '📈' },
  { name: 'Typeform', description: 'Create beautiful online forms and surveys.', link: 'https://typeform.com', category: Category.MARKETING, icon: '📈' },
  { name: 'Bitly', description: 'URL Shortener.', link: 'https://bitly.com/', category: Category.MARKETING, icon: '📈' },
  
  // Utilities
  { name: '123apps', description: 'A suite of free online tools.', link: 'https://123apps.com/', category: Category.UTILITIES, icon: '🔧' },
  { name: 'TinyPNG', description: 'Smart PNG and JPEG compression.', link: 'https://tinypng.com', category: Category.UTILITIES, icon: '🔧' },
  { name: 'Smallpdf', description: 'PDF tools for everyone.', link: 'https://smallpdf.com', category: Category.UTILITIES, icon: '🔧' },
  { name: 'WeTransfer', description: 'Send large files.', link: 'https://wetransfer.com', category: Category.UTILITIES, icon: '🔧' },
  { name: 'VirusTotal', description: 'Analyze suspicious files and URLs.', link: 'https://virustotal.com', category: Category.UTILITIES, icon: '🔧' },
  { name: 'Online-Convert', description: 'Convert files from one format to another.', link: 'https://www.online-convert.com', category: Category.UTILITIES, icon: '🔧' },
  { name: '10MinuteMail', description: 'Disposable temporary email.', link: 'https://10minutemail.com', category: Category.UTILITIES, icon: '🔧' },
  { name: 'Privacy Badger', description: 'Browser extension that stops advertisers.', link: 'https://privacybadger.org/', category: Category.UTILITIES, icon: '🔧' },
  { name: 'DuckDuckGo', description: 'The search engine that doesn\'t track you.', link: 'https://duckduckgo.com', category: Category.UTILITIES, icon: '🔧' },
  { name: 'Wayback Machine', description: 'Explore archived versions of websites.', link: 'https://archive.org/web/', category: Category.UTILITIES, icon: '🔧' },
  { name: 'Photopea', description: 'Free online photo editor.', link: 'https://www.photopea.com/', category: Category.UTILITIES, icon: '🔧' },
  { name: 'WhatTheFont', description: 'Identify fonts from an image.', link: 'https://www.myfonts.com/pages/whatthefont', category: Category.UTILITIES, icon: '🔧' },

  // Finance
  { name: 'Mint', description: 'Money management app.', link: 'https://mint.intuit.com', category: Category.FINANCE, icon: '💰' },
  { name: 'YNAB', description: 'You Need A Budget. Budgeting app.', link: 'https://youneedabudget.com', category: Category.FINANCE, icon: '💰' },
  { name: 'PayPal', description: 'Online payments system.', link: 'https://paypal.com', category: Category.FINANCE, icon: '💰' },
  { name: 'Stripe', description: 'Online payment processing for internet businesses.', link: 'https://stripe.com', category: Category.FINANCE, icon: '💰' },
  { name: 'QuickBooks', description: 'Accounting software for small businesses.', link: 'https://quickbooks.intuit.com', category: Category.FINANCE, icon: '💰' },
  { name: 'Robinhood', description: 'Commission-free stock trading & investing app.', link: 'https://robinhood.com', category: Category.FINANCE, icon: '💰' },
  { name: 'NerdWallet', description: 'Make all the right money moves.', link: 'https://nerdwallet.com', category: Category.FINANCE, icon: '💰' },
  { name: 'Wise', description: 'Transfer money abroad easily and quickly.', link: 'https://wise.com/', category: Category.FINANCE, icon: '💰' },
  { name: 'Splitwise', description: 'Split bills with friends.', link: 'https://www.splitwise.com/', category: Category.FINANCE, icon: '💰' },
  { name: 'Coinbase', description: 'Buy and sell cryptocurrency.', link: 'https://www.coinbase.com/', category: Category.FINANCE, icon: '💰' },
  { name: 'Gumroad', description: 'Sell digital products directly to your audience.', link: 'https://gumroad.com/', category: Category.FINANCE, icon: '💰' },
  
  // AI
  { name: 'ChatGPT', description: 'Conversational AI by OpenAI.', link: 'https://chat.openai.com', category: Category.AI, icon: '🤖' },
  { name: 'Gemini', description: 'Multimodal AI by Google.', link: 'https://gemini.google.com/', category: Category.AI, icon: '🤖' },
  { name: 'Midjourney', description: 'AI image generator.', link: 'https://midjourney.com', category: Category.AI, icon: '🤖' },
  { name: 'DALL-E 3', description: 'AI image generator from OpenAI.', link: 'https://openai.com/dall-e-3', category: Category.AI, icon: '🤖' },
  { name: 'Synthesia', description: 'AI video generation platform.', link: 'https://synthesia.io', category: Category.AI, icon: '🤖' },
  { name: 'RunwayML', description: 'AI video editing tools.', link: 'https://runwayml.com/', category: Category.AI, icon: '🤖' },
  { name: 'Poe', description: 'Fast, helpful AI chat.', link: 'https://poe.com', category: Category.AI, icon: '🤖' },
  { name: 'Perplexity AI', description: 'Conversational search engine.', link: 'https://perplexity.ai', category: Category.AI, icon: '🤖' },
  { name: 'Otter.ai', description: 'AI meeting assistant that records audio.', link: 'https://otter.ai', category: Category.AI, icon: '🤖' },
  { name: 'Murf.ai', description: 'AI Voice Generator.', link: 'https://murf.ai/', category: Category.AI, icon: '🤖' },
  { name: 'Looka', description: 'AI-powered logo maker.', link: 'https://looka.com/', category: Category.AI, icon: '🤖' },
  { name: 'GitHub Copilot', description: 'Your AI pair programmer.', link: 'https://github.com/features/copilot', category: Category.AI, icon: '🤖' },
];
