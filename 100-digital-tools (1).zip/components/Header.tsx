
import React from 'react';

const Header: React.FC = () => (
  <header className="text-center mb-12">
    <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600 mb-4">
      100 Digital Tools
    </h1>
    <p className="max-w-2xl mx-auto text-lg text-gray-400">
      A curated collection of essential online tools to boost your productivity, creativity, and efficiency.
    </p>
  </header>
);

export default Header;
