
import React from 'react';
import { Tool } from '../types';
import { CATEGORY_STYLES } from '../constants';

interface ToolCardProps {
  tool: Tool;
}

const ExternalLinkIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 6H5.25A2.25 2.25 0 003 8.25v10.5A2.25 2.25 0 005.25 21h10.5A2.25 2.25 0 0018 18.75V10.5m-10.5 6L21 3m0 0h-5.25M21 3v5.25" />
    </svg>
);


const ToolCard: React.FC<ToolCardProps> = ({ tool }) => {
  const categoryStyle = CATEGORY_STYLES[tool.category];

  return (
    <a
      href={tool.link}
      target="_blank"
      rel="noopener noreferrer"
      className="group block h-full"
    >
      <div className="flex flex-col justify-between h-full bg-gray-800 border border-gray-700 rounded-xl p-6 transition-all duration-300 ease-in-out hover:border-purple-500 hover:shadow-2xl hover:shadow-purple-500/10 hover:-translate-y-2">
        <div>
          <div className="flex items-center justify-between mb-4">
            <span className="text-4xl">{tool.icon}</span>
            <span className={`px-3 py-1 text-xs font-bold rounded-full text-white ${categoryStyle.color}`}>
              {tool.category}
            </span>
          </div>
          <h3 className="text-xl font-bold text-gray-100 mb-2">{tool.name}</h3>
          <p className="text-gray-400 text-sm leading-relaxed">{tool.description}</p>
        </div>
        <div className="mt-6 flex items-center justify-end text-sm font-medium text-gray-500 group-hover:text-purple-400 transition-colors duration-300">
          <span>Visit Tool</span>
          <ExternalLinkIcon className="w-4 h-4 ml-1" />
        </div>
      </div>
    </a>
  );
};

export default ToolCard;
